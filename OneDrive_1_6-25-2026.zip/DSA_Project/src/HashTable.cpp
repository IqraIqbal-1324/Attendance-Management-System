#include "HashTable.h"

void HashTable::addStudent(const Student &student) {
    table[student.rollNumber] = student;
}

bool HashTable::findStudent(int rollNumber, Student &student) const {
    auto it = table.find(rollNumber);
    if (it != table.end()) {
        student = it->second;
        return true;
    }
    return false;
}

void HashTable::updateAttendance(int rollNumber, float attendance) {
    if (table.find(rollNumber) != table.end()) {
        table[rollNumber].attendancePercentage = attendance;
    }
}
