#include "Student.h"

// Default constructor
Student::Student() : rollNumber(0), name(""), attendancePercentage(0.0) {}

// Parameterized constructor
Student::Student(int rollNumber, const std::string &name, float attendancePercentage)
    : rollNumber(rollNumber), name(name), attendancePercentage(attendancePercentage) {}
