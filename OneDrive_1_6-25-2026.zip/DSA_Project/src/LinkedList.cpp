#include "LinkedList.h"
#include <iostream>

LinkedList::LinkedList() : head(nullptr) {}

LinkedList::~LinkedList() {
    Node* current = head;
    while (current) {
        Node* temp = current;
        current = current->next;
        delete temp;
    }
}

void LinkedList::addStudent(const Student &student) {
    Node* newNode = new Node(student);
    if (!head) {
        head = newNode;
    } else {
        Node* temp = head;
        while (temp->next) {
            temp = temp->next;
        }
        temp->next = newNode;
    }
}

bool LinkedList::deleteStudent(int rollNumber) {
    Node* temp = head;
    Node* prev = nullptr;

    while (temp) {
        if (temp->student.rollNumber == rollNumber) {
            if (prev) {
                prev->next = temp->next;
            } else {
                head = temp->next;
            }
            delete temp;
            return true;
        }
        prev = temp;
        temp = temp->next;
    }
    return false;
}

void LinkedList::displayStudents() const {
    Node* temp = head;
    while (temp) {
        std::cout << "Roll Number: " << temp->student.rollNumber
                  << ", Name: " << temp->student.name
                  << ", Attendance: " << temp->student.attendancePercentage << "%" << std::endl;
        temp = temp->next;
    }
}
