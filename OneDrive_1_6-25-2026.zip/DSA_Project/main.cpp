#include "LinkedList.h"
#include "HashTable.h"
#include <iostream>

int main() {
    LinkedList studentList;
    HashTable studentTable;

    int choice;
    do {
        std::cout << "\nAttendance Management System\n";
        std::cout << "1. Add Student\n2. Delete Student\n3. Display All Students\n";
        std::cout << "4. Search Student by Roll Number\n5. Update Attendance\n0. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1: {
                int rollNumber;
                std::string name;
                std::cout << "Enter Roll Number: ";
                std::cin >> rollNumber;
                std::cout << "Enter Name: ";
                std::cin.ignore();
                std::getline(std::cin, name);

                Student student(rollNumber, name);
                studentList.addStudent(student);
                studentTable.addStudent(student);
                break;
            }
            case 2: {
                int rollNumber;
                std::cout << "Enter Roll Number to Delete: ";
                std::cin >> rollNumber;

                if (studentList.deleteStudent(rollNumber)) {
                    std::cout << "Student Deleted Successfully!\n";
                } else {
                    std::cout << "Student Not Found!\n";
                }
                break;
            }
            case 3:
                studentList.displayStudents();
                break;

            case 4: {
                int rollNumber;
                std::cout << "Enter Roll Number to Search: ";
                std::cin >> rollNumber;

                Student student(0, "");
                if (studentTable.findStudent(rollNumber, student)) {
                    std::cout << "Found: Roll Number: " << student.rollNumber
                              << ", Name: " << student.name
                              << ", Attendance: " << student.attendancePercentage << "%\n";
                } else {
                    std::cout << "Student Not Found!\n";
                }
                break;
            }

            case 5: {
                int rollNumber;
                float attendance;
                std::cout << "Enter Roll Number: ";
                std::cin >> rollNumber;
                std::cout << "Enter Attendance Percentage: ";
                std::cin >> attendance;

                studentTable.updateAttendance(rollNumber, attendance);
                std::cout << "Attendance Updated!\n";
                break;
            }

            case 0:
                std::cout << "Exiting...\n";
                break;

            default:
                std::cout << "Invalid Choice! Try Again.\n";
        }
    } while (choice != 0);

    return 0;
}
