#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include "Student.h"

class LinkedList {
private:
    struct Node {
        Student student;
        Node* next;

        Node(const Student &student) : student(student), next(nullptr) {}
    };

    Node* head;

public:
    LinkedList();
    ~LinkedList();

    void addStudent(const Student &student);
    bool deleteStudent(int rollNumber);
    void displayStudents() const;
};

#endif
