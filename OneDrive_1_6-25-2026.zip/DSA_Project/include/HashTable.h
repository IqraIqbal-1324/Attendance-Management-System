#ifndef HASHTABLE_H
#define HASHTABLE_H

#include "Student.h"
#include <unordered_map>

class HashTable {
private:
    std::unordered_map<int, Student> table;

public:
    void addStudent(const Student &student);
    bool findStudent(int rollNumber, Student &student) const;
    void updateAttendance(int rollNumber, float attendance);
};

#endif

