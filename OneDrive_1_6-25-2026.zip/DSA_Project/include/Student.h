#ifndef STUDENT_H
#define STUDENT_H

#include <string>

class Student {
public:
    int rollNumber;
    std::string name;
    float attendancePercentage;

    // Default constructor (Required for unordered_map)
    Student();

    // Parameterized constructor
    Student(int rollNumber, const std::string &name, float attendancePercentage = 0.0);
};

#endif


